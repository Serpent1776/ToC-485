public class PDAException extends Exception {//I can't go without an unique Exception class to capture those nasty bugs!
    public PDAException() {
        super();
    }
    public PDAException(String message) {
        super(message);
    }
}
