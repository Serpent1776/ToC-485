public class AutomatonException extends Exception {
    public AutomatonException() {
        super();
    }
    public AutomatonException(String message) {
        super(message);
    }
}
